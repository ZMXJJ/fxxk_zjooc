# 使用 Docker 部署

构建 docker image

```bash
sudo docker build -t zjooc .
```

运行 docker image

```bash
sudo docker run -it --rm zjooc
```
